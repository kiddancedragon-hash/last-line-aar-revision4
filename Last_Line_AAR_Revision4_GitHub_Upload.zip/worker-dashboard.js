// Generated offline from reviewed modules; deployment requires explicit approval.
// SOURCE: schema.mjs
export const MAX_REPORT_BYTES = 786432;
class SchemaError extends Error { constructor() { super('Invalid report'); this.name = 'SchemaError'; } }
const fail = () => { throw new SchemaError(); };
const test = value => { if (!value) fail(); };
const obj = v => !!v && typeof v === 'object' && !Array.isArray(v);
const text = (v, max = 160) => typeof v === 'string' && v.length <= max && !/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/.test(v);
const nonempty = (v, max = 160) => text(v,max) && v.length > 0;
const number = v => typeof v === 'number' && Number.isFinite(v) && Math.abs(v) <= 1e12;
const int = (v, min = 0, max = 1e9) => Number.isSafeInteger(v) && v >= min && v <= max;
const id = v => nonempty(v, 160) && /^[a-zA-Z0-9_.|: -]+$/.test(v);
const identifier = v => nonempty(v,128) && /^[a-zA-Z0-9_-]+$/.test(v);
const uuid = v => typeof v==='string' && /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/.test(v);
function keys(v, required, optional = []) {
  test(obj(v)); const all = new Set([...required,...optional]);
  test(required.every(k => Object.hasOwn(v,k)) && Object.keys(v).every(k => all.has(k)));
}
function list(v, max, validate) { test(Array.isArray(v) && v.length <= max); for (const item of v) validate(item); }
function dictionary(v, max, validate, keyOK = identifier) { test(obj(v) && Object.keys(v).length <= max); for (const [k,item] of Object.entries(v)) { test(keyOK(k)); validate(item); } }
export function stableJSON(v) {
  if (Array.isArray(v)) return '[' + v.map(stableJSON).join(',') + ']';
  if (obj(v)) return '{' + Object.keys(v).sort().map(k=>JSON.stringify(k)+':'+stableJSON(v[k])).join(',') + '}';
  return JSON.stringify(v);
}
function build(v) { keys(v,['game_version','build_id','balance_revision']); test(id(v.game_version) && id(v.build_id) && id(v.balance_revision)); }
function progression(v) {
  keys(v,['requisition','owned','roster','enemy_unlocks','faction_entitlements','upgrades','starting_equipment','resources','weapon_unlocks','perk_history']);
  test(number(v.requisition) && v.requisition >= 0);
  for (const key of ['owned','roster','enemy_unlocks']) list(v[key],512,x=>test(identifier(x)));
  dictionary(v.faction_entitlements,32,x=>test(typeof x==='boolean'));
  keys(v.upgrades,['rerollLevel','deleteLevel','mineLevel','mapResearchLevel','r2Ascendancy']);
  for(const key of ['rerollLevel','deleteLevel','mineLevel','mapResearchLevel']) test(int(v.upgrades[key]));
  dictionary(v.upgrades.r2Ascendancy,4,x=>dictionary(x,128,n=>test(int(n))),k=>['Astra Militarum','Adeptus Astartes','Adeptus Custodes','Space Wolves'].includes(k));
  test(v.starting_equipment===null || ['mine','barricade'].includes(v.starting_equipment));
  test(Array.isArray(v.resources)&&v.resources.length===4&&v.resources.every(number));
  dictionary(v.weapon_unlocks,512,x=>list(x,128,s=>test(nonempty(s,256))));
  dictionary(v.perk_history,1024,x=>test(int(x)));
}
const EVENT_KINDS = new Set(['Bastion configuration','Bastion loadout chosen','additional loadout changed','armoury unlocked','automatic lethal rescue','battlefield selected','casualty','choice pending','configuration chosen','deep strike selected','deleted/rerolled away','equipment placed','explicitly saved resources','loadout chosen','map rerolled','offers','purchased/deployed','rerolled away','research purchased','resolved with resources retained','resources carried forward','roster','roster update','roster selected','roster skipped','sacrificed/refund','selected for placement','starting equipment chosen','strategic territory receipt','terrain placed','terrain selected','territory purchased','chosen','ability activated','ability armed','ability relocated','ability target chosen','ability targeting selected','ability targeting cancelled','charge destination chosen','manual attack chosen','missile targeting selected','promotion branch chosen','reaction destination chosen','reaction skipped','signature restoration chosen','support target chosen','blocked choice','guaranteed starter discovered']);
function nativeAAR(a) {
  keys(a,['schema','run','build','startedWave','priorUnavailable','defs','contexts','batches','events','economy','waves','combat','seq','lastWallet','lastRoster','seen','outcome','seed'],['optionSets','combatTotals','seedScope','lastBastion','battlefield']);
  test(a.schema===1&&identifier(a.run)&&a.run.length<=64&&nonempty(a.build,160)&&int(a.startedWave,1,1000)&&typeof a.priorUnavailable==='boolean');
  test(a.seed===null||Number.isSafeInteger(a.seed)); test(a.seedScope===undefined||['combat-only','run seed field'].includes(a.seedScope));
  test(['Victory','Defeat'].includes(a.outcome)&&int(a.seq,0,1e7));
  list(a.defs,20000,d=>test(Array.isArray(d)&&d.length===6&&d.every(x=>text(x,4096))));
  list(a.contexts,20000,c=>test(Array.isArray(c)&&c.length===9&&c.every(number)&&int(c[0],1,1000)&&int(c[1])));
  const def = n=>int(n,0,a.defs.length-1), batch = n=>int(n,0,a.batches.length-1);
  const option = o=>test(Array.isArray(o)&&o.length===7&&def(o[0])&&number(o[1])&&o[1]>=0&&['points','xp','rerolls','deletes'].includes(o[2])&&[0,1].includes(o[3])&&text(o[4],256)&&number(o[5])&&o[5]>=0&&[0,1].includes(o[6]));
  if(a.optionSets!==undefined) list(a.optionSets,20000,set=>list(set,512,option));
  list(a.batches,20000,b=>{test(Array.isArray(b)&&b.length===3&&text(b[0],256)&&int(b[1],0,a.contexts.length-1)); if(Array.isArray(b[2]))list(b[2],512,option); else test(int(b[2],0,(a.optionSets?.length||0)-1));});
  function roster(rows) { list(rows,70,r=>test(Array.isArray(r)&&r.length===8&&int(r[0])&&def(r[1])&&int(r[2],0,9)&&int(r[3],0,6)&&number(r[4])&&number(r[5])&&r[5]>0&&[0,1].includes(r[6])&&Array.isArray(r[7])&&r[7].length<=64&&r[7].every(w=>text(w,256)))); }
  function parsed(s,max=100000) {test(text(s,max));try{return JSON.parse(s);}catch{fail();}}
  test(Array.isArray(a.lastWallet)&&a.lastWallet.length===4&&a.lastWallet.every(x=>number(x)&&x>=0));
  test(text(a.lastRoster,100000));if(a.lastRoster) roster(parsed(a.lastRoster));
  if(a.lastBastion!==undefined){const b=parsed(a.lastBastion,256);test(Array.isArray(b)&&b.length===2&&text(b[0],80)&&typeof b[1]==='boolean');}
  let previous=0;
  list(a.events,20000,e=>{
    test(Array.isArray(e)&&e.length===7&&int(e[0],1,a.seq)&&e[0]>previous&&int(e[1],1,1000)&&int(e[2])&&EVENT_KINDS.has(e[3])&&(e[4]===null||batch(e[4]))&&(e[5]===null||def(e[5]))&&text(e[6],100000)); previous=e[0];
    if(e[3]==='roster')roster(parsed(e[6]));
    if(e[3]==='roster update'){const p=parsed(e[6]);test(Array.isArray(p)&&p.length===2);roster(p[0]);list(p[1],70,x=>test(text(x,80)));}
  });
  dictionary(a.seen,20000,x=>test(batch(x)),k=>text(k,256)&&!['__proto__','prototype','constructor'].includes(k));
  const waveKey=k=>/^\d{1,4}$/.test(k)&&Number(k)>=1&&Number(k)<=1000;
  dictionary(a.combat,1000,rows=>list(rows,20000,r=>test(Array.isArray(r)&&[2,3].includes(r.length)&&text(r[0],8192)&&int(r[1],1)&&(r[2]===undefined||text(r[2],8192)))),waveKey);
  if(a.combatTotals!==undefined)dictionary(a.combatTotals,1000,rows=>list(rows,20000,r=>test(Array.isArray(r)&&r.length===5&&text(r[0],4096)&&text(r[1],256)&&r.slice(2).every(x=>number(x)&&x>=0))),waveKey);
  list(a.economy,20000,r=>test(Array.isArray(r)&&[11,12].includes(r.length)&&text(r[2],256)&&r.every((n,i)=>i===2||number(n))&&int(r[0],1,1000)&&int(r[1])&&(r[11]===undefined||int(r[11],0,a.seq))));
  const waves=new Set();list(a.waves,1000,r=>{test(Array.isArray(r)&&r.length===10&&r.slice(0,8).every(number)&&int(r[0],1,1000)&&!waves.has(r[0])&&text(r[8],128)&&[null,'Victory','Defeat'].includes(r[9]));waves.add(r[0]);});
  if(a.battlefield!==undefined) battlefield(a.battlefield,a);
}

// Optional battlefield schema 1. Absence in older reports means unavailable, never an empty battlefield.
const BATTLEFIELD_STATUS_KEYS = new Set(["actionUsed","movedTurn","cavalryMoveUsed","cavalryMoveSpent","vehicleFreeMoveUsed","bankedMoves","sharedFreeMovementR2","temporaryMoveCapacityR2","deepStrikeReadyTurn","shield","armor","inv","save","toughness","speed","regen","burnStacks","burnDueTurn","psychicSuppressedRound","stunActive","stunRound","stunStopsMove","stunDisabledProfile","shockStopsMove","shockSpent","synapticShock","synapseCovered","stationaryPlatform","burrowPending","r2CargoPending","r2CargoUnloaded","r2UnloadRound","r2FortressPending","r2TalonPending","r2MomentPending","r2MomentRound","r2SignatureUsed","r2SquadSignatureUsed","r2Doctrine","r2DoctrineWave","r2DoctrineMoveUsed","lastTurnStationary","r2EnemyTradeoffWave","r2FirstActivationWave","hp_max_source","shield_source","aura_vanguard_cells","aura_deadeye_cells","aura_aegis_cells","aura_paragon_cells","weapon","stance"]);
function battlefield(v, a) {
  keys(v,['schema_version','started_wave','prior_unavailable','coordinate_system','snapshot_seq','entity_seq','resolve_seq','layouts','snapshots','actions','dropped','coverage']);
  test(v.schema_version===1 && int(v.started_wave,1,1000) && typeof v.prior_unavailable==='boolean' && v.coordinate_system==='zero_based_row_column');
  for (const key of ['snapshot_seq','entity_seq','resolve_seq']) test(int(v[key],0,1e7));
  const scalar=n=>number(n)&&Math.abs(n)<=1e9, positive=n=>scalar(n)&&n>0, nonnegative=n=>scalar(n)&&n>=0;
  const nullable=(n,check=nonnegative)=>n===null||check(n);
  const coord=c=>Array.isArray(c)&&c.length===2&&int(c[0],0,9)&&int(c[1],0,6);
  const eid=n=>int(n,1,v.entity_seq);
  const layouts=new Set(), sequences=new Set();
  list(v.layouts,128,l=>{
    keys(l,['id','rows','cols','map','cells']);test(int(l.id,0,1e7)&&!layouts.has(l.id)&&l.rows===10&&l.cols===7&&text(l.map,128));layouts.add(l.id);
    const occupied=new Set();
    list(l.cells,70,c=>{test(Array.isArray(c)&&c.length===9&&coord(c.slice(0,2))&&typeof c[2]==='boolean'&&text(c[3],80)&&text(c[4],80)&&c.slice(5,8).every(n=>nullable(n))&&typeof c[8]==='boolean');const k=c[0]+':'+c[1];test(!occupied.has(k));occupied.add(k);});
  });
  const chronology=(x,previous)=>{
    test(int(x.seq,1,v.snapshot_seq)&&x.seq>previous&&!sequences.has(x.seq));sequences.add(x.seq);
    test(int(x.aar_seq,0,a.seq)&&int(x.wave,1,1000)&&int(x.turn,0,1e7)&&int(x.resolve,0,v.resolve_seq));
  };
  let previous=0;
  list(v.snapshots,128,s=>{
    keys(s,['seq','aar_seq','reason','wave','turn','resolve','phase','at_ms','build','complete','layout','entities','pending','objective','resources','summary']);
    chronology(s,previous);previous=s.seq;
    test(['wave_start','before_resolve','after_resolve','wave_clear','defeat','victory','load'].includes(s.reason)&&text(s.phase,80)&&int(s.at_ms,0,Number.MAX_SAFE_INTEGER)&&nonempty(s.build,256)&&typeof s.complete==='boolean'&&layouts.has(s.layout));
    const ids=new Set(), occupied=new Set(), totals={enemy_count:0,enemy_hp:0,enemy_max_hp:0,friendly_count:0,friendly_hp:0,friendly_max_hp:0};
    list(s.entities,70,e=>{
      test(Array.isArray(e)&&e.length===12&&eid(e[0])&&!ids.has(e[0])&&['troop','enemy'].includes(e[1])&&nonempty(e[2],80)&&text(e[3],128)&&positive(e[4])&&nullable(e[5],positive)&&nullable(e[6])&&coord(e[7])&&typeof e[10]==='boolean'&&(e[11]===null||int(e[11],0,1e7)));ids.add(e[0]);
      const cells=new Set();list(e[8],9,c=>{test(coord(c));const k=c.join(':');test(!cells.has(k)&&!occupied.has(k));cells.add(k);occupied.add(k);});test(cells.size>0&&cells.has(e[7].join(':')));
      dictionary(e[9],52,x=>test(x===null||typeof x==='boolean'||scalar(x)||text(x,160)),k=>BATTLEFIELD_STATUS_KEYS.has(k));
      const side=e[1]==='enemy'?'enemy':'friendly';totals[side+'_count']++;totals[side+'_hp']+=e[4];if(e[5]===null)totals[side+'_max_hp']=null;else if(totals[side+'_max_hp']!==null)totals[side+'_max_hp']+=e[5];
    });
    keys(s.pending,['reserves','warnings','composition']);test(int(s.pending.reserves,0,1e7)&&int(s.pending.warnings,0,70)&&s.pending.composition==='withheld');
    keys(s.objective,['hp','max_hp','boss']);test(scalar(s.objective.hp)&&positive(s.objective.max_hp));
    if(s.objective.boss!==null){
      const b=s.objective.boss;keys(b,['phase','row','rounds','remaining','damage','shots','emergency','orbital','cutscenePending','hp','max_hp','hp_model']);
      test(b.phase===null||text(b.phase,80));for(const k of ['row','rounds','remaining','damage','shots','emergency'])test(nullable(b[k],scalar));for(const k of ['orbital','cutscenePending'])test(b[k]===null||typeof b[k]==='boolean');
      test(b.hp===null&&b.max_hp===null&&b.hp_model==='orbital_objective');
    }
    test(Array.isArray(s.resources)&&s.resources.length===5&&s.resources.every(scalar));
    keys(s.summary,Object.keys(totals));for(const [key,value] of Object.entries(totals))test(value===null?s.summary[key]===null:number(s.summary[key])&&Math.abs(s.summary[key]-value)<=1e-6);
  });
  previous=0;
  list(v.actions,512,x=>{
    keys(x,['seq','aar_seq','wave','turn','resolve','kind','entity','source','from','to','hp_before','hp_after','shield_before','shield_after','detail']);
    chronology(x,previous);previous=x.seq;
    test(['deploy','move','damage','casualty','remove','transform'].includes(x.kind)&&eid(x.entity)&&(x.source===null||eid(x.source))&&(x.from===null||coord(x.from))&&(x.to===null||coord(x.to))&&text(x.detail,160));
    for(const key of ['hp_before','hp_after'])test(nullable(x[key],scalar));for(const key of ['shield_before','shield_after'])test(nullable(x[key]));
  });
  keys(v.dropped,['snapshots','actions','first_seq','last_seq']);
  for(const key of ['snapshots','actions'])test(int(v.dropped[key],0,1e7));
  for(const key of ['first_seq','last_seq'])test(v.dropped[key]===null||int(v.dropped[key],1,v.snapshot_seq));
  test((v.dropped.first_seq===null)===(v.dropped.last_seq===null));
  if(v.dropped.first_seq!==null)test(v.dropped.first_seq<=v.dropped.last_seq);
  list(v.coverage,16,x=>test(nonempty(x,160)));
  test(new TextEncoder().encode(JSON.stringify(v)).byteLength<=262144);
}

export function validateBattlefield(v, nativeSeq=1e7) { test(int(nativeSeq,0,1e7)); battlefield(v,{seq:nativeSeq}); return true; }
export function validateReport(r) {
  keys(r,['schema_version','run_id','game_version','build_id','balance_revision','mode','faction','map','result','final_wave','provenance','completeness','progression','summary','aar']);
  test(r.schema_version===2&&uuid(r.run_id));
  test(id(r.game_version)&&id(r.build_id)&&id(r.balance_revision)&&['normal','dev','test'].includes(r.mode)&&identifier(r.faction)&&identifier(r.map)&&['victory','defeat'].includes(r.result)&&int(r.final_wave,1,1000));
  const p=r.provenance;keys(p,['origin','builds','mixed_build','legacy_report_build','origin_unknown','continuation_of']);build(p.origin);list(p.builds,32,build);test(p.builds.length>0&&typeof p.mixed_build==='boolean'&&typeof p.origin_unknown==='boolean'&&(p.legacy_report_build===null||text(p.legacy_report_build,160)));
  test(p.continuation_of===null || uuid(p.continuation_of) && p.continuation_of!==r.run_id);
  test(['game_version','build_id','balance_revision'].every(k=>p.origin[k]===r[k]));
  test(stableJSON(p.builds[0])===stableJSON(p.origin));test(p.mixed_build===(new Set(p.builds.map(stableJSON)).size>1));
  const c=r.completeness;keys(c,['prior_unavailable','migrated','baseline_available','unavailable_metrics']);test(['prior_unavailable','migrated','baseline_available'].every(k=>typeof c[k]==='boolean'));list(c.unavailable_metrics,32,x=>test(nonempty(x,256)));
  keys(r.progression,['start','end']);test(c.baseline_available===(r.progression.start!==null));if(r.progression.start!==null)progression(r.progression.start);progression(r.progression.end);
  const s=r.summary;keys(s,['kills','bastion_hp','bastion_max_hp','points','xp','run_stats']);test(['kills','bastion_hp','bastion_max_hp','points','xp'].every(k=>number(s[k]))&&s.kills>=0&&s.bastion_max_hp>0);
  list(s.run_stats,512,x=>{keys(x,['id','type','damage','kills','fallen']);test(int(x.id)&&identifier(x.type)&&number(x.damage)&&x.damage>=0&&int(x.kills)&&typeof x.fallen==='boolean');});
  nativeAAR(r.aar);test(r.result===r.aar.outcome.toLowerCase()&&c.prior_unavailable===r.aar.priorUnavailable&&r.final_wave>=r.aar.startedWave);
  return true;
}

// SOURCE: receiver.mjs

const enc = new TextEncoder();
const json = (data, status = 200, headers = {}) => new Response(JSON.stringify(data), {
  status, headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff', ...headers }
});
function origins(env) {
  try {
    const list = JSON.parse(env.AAR_ALLOWED_ORIGINS || '[]');
    if (!Array.isArray(list) || !list.length || list.length > 8) return [];
    return list.every(o => typeof o === 'string' && new URL(o).origin === o && new URL(o).protocol === 'https:') ? list : [];
  } catch { return []; }
}
function enabled(env) {
  return env.AAR_UPLOADS_ENABLED === 'true' && env.AAR_STAGING_REVIEWED === 'true' &&
    origins(env).length > 0 && typeof env.AAR_TURNSTILE_SITEKEY === 'string' && env.AAR_TURNSTILE_SITEKEY.length > 0 &&
    typeof env.AAR_TURNSTILE_SECRET === 'string' && env.AAR_TURNSTILE_SECRET.length > 0 &&
    !!env.DB?.prepare && typeof env.AAR_RATE_LIMITER?.limit === 'function';
}
export async function sha256(text) {
  return [...new Uint8Array(await crypto.subtle.digest('SHA-256', enc.encode(text)))].map(b => b.toString(16).padStart(2, '0')).join('');
}
async function boundedBody(request, limit) {
  const claimed = request.headers.get('Content-Length');
  if (claimed && (!/^\d+$/.test(claimed) || Number(claimed) > limit)) throw { status: 413, error: 'report_too_large' };
  if (request.headers.has('Content-Encoding') && request.headers.get('Content-Encoding') !== 'identity') throw { status: 415, error: 'encoding_not_supported' };
  const reader = request.body?.getReader();
  if (!reader) throw { status: 400, error: 'empty_body' };
  const decoder = new TextDecoder('utf-8', { fatal: true });
  let count = 0, text = '';
  try {
    for (;;) {
      const { value, done } = await reader.read();
      if (done) break;
      count += value.byteLength;
      if (count > limit) { await reader.cancel(); throw { status: 413, error: 'report_too_large' }; }
      text += decoder.decode(value, { stream: true });
    }
    text += decoder.decode();
  } catch (e) { throw e.status ? e : { status: 400, error: 'unreadable_body' }; }
  // Bound nesting before JSON parsing to avoid a deeply nested parse/canonicalize attack.
  let depth = 0, string = false, escaped = false;
  for (const ch of text) {
    if (string) { if (escaped) escaped = false; else if (ch === '\\') escaped = true; else if (ch === '"') string = false; }
    else if (ch === '"') string = true;
    else if (ch === '[' || ch === '{') { if (++depth > 16) throw { status: 422, error: 'nesting_limit' }; }
    else if (ch === ']' || ch === '}') depth--;
  }
  try { return JSON.parse(text); } catch { throw { status: 400, error: 'invalid_json' }; }
}
async function verifyToken(token, runID, origin, env) {
  if (typeof token !== 'string' || !token || token.length > 2048) return { status: 403, error: 'token_required' };
  const controller = new AbortController(), timeout = setTimeout(() => controller.abort(), 10000);
  try {
    const response = await fetch('https://challenges.cloudflare.com/turnstile/v0/siteverify', {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, signal: controller.signal,
      // No IP, device identifiers, gameplay report or personal fields are sent to this verifier.
      body: JSON.stringify({ secret: env.AAR_TURNSTILE_SECRET, response: token })
    });
    if (!response.ok) return { status: 503, error: 'verification_unavailable' };
    const value = await response.json();
    if (value.success !== true || value.hostname !== new URL(origin).hostname || value.action !== 'last_line_aar' || value.cdata !== runID)
      return { status: 403, error: 'token_rejected' };
    return null;
  } catch { return { status: 503, error: 'verification_unavailable' }; }
  finally { clearTimeout(timeout); }
}
async function storeReport(report, env) {
  const raw = stableJSON(report), bytes = enc.encode(raw).byteLength;
  if (bytes > MAX_REPORT_BYTES) return json({ error: 'report_too_large' }, 413);
  const digest = await sha256(raw);
  const prior = await env.DB.prepare('SELECT digest FROM aar_reports_v2 WHERE run_id=?1').bind(report.run_id).first();
  if (prior) return json(prior.digest === digest ? { ok: true, run_id: report.run_id, digest, status: 'duplicate' } : { error: 'digest_conflict', run_id: report.run_id }, prior.digest === digest ? 200 : 409);
  const inserted = await env.DB.prepare(`INSERT INTO aar_reports_v2
    (run_id,digest,schema_version,game_version,build_id,balance_revision,mode,faction,map,result,final_wave,event_count,payload_bytes,report_json)
    VALUES (?1,?2,?3,?4,?5,?6,?7,?8,?9,?10,?11,?12,?13,?14) ON CONFLICT(run_id) DO NOTHING`)
    .bind(report.run_id, digest, report.schema_version, report.game_version, report.build_id, report.balance_revision,
      report.mode, report.faction, report.map, report.result, report.final_wave, report.aar.events.length, bytes, raw).run();
  // Another request can win the unique run ID between the read and insert. Compare again.
  const stored = await env.DB.prepare('SELECT digest FROM aar_reports_v2 WHERE run_id=?1').bind(report.run_id).first();
  if (!stored) return json({ error: 'storage_unavailable' }, 503);
  if (stored.digest !== digest) return json({ error: 'digest_conflict', run_id: report.run_id }, 409);
  return json({ ok: true, run_id: report.run_id, digest, status: inserted.meta?.changes ? 'stored' : 'duplicate' }, 200);
}
async function authorizedExport(request, env) {
  const expected = env.AAR_EXPORT_TOKEN, auth = request.headers.get('Authorization');
  if (typeof expected !== 'string' || expected.length < 32 ||
      typeof env.AAR_TEST_TOKEN === 'string' && expected === env.AAR_TEST_TOKEN ||
      typeof env.AAR_TURNSTILE_SECRET === 'string' && expected === env.AAR_TURNSTILE_SECRET || !auth?.startsWith('Bearer ')) return false;
  const supplied = auth.slice(7);
  if (supplied.length > 256) return false;
  const a = await sha256(supplied), b = await sha256(expected); let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}
async function exportReports(request, env, url) {
  if (request.method !== 'GET') return json({ error: 'method_not_allowed' }, 405);
  if (!await authorizedExport(request, env)) return json({ error: 'unauthorized' }, 401);
  const q = url.searchParams, allowed = new Set(['after','limit','format','mode','game_version','build_id','balance_revision','schema_version','result']);
  if ([...q.keys()].some(k => !allowed.has(k)) || [...allowed].some(k => q.getAll(k).length > 1)) return json({ error: 'invalid_filter' }, 400);
  const after = q.get('after') || '0', limit = q.get('limit') || '10', format = q.get('format') || 'json';
  if (!/^\d{1,15}$/.test(after) || !/^(?:[1-9]|10)$/.test(limit) || !['json','jsonl'].includes(format)) return json({ error: 'invalid_pagination' }, 400);
  const clauses = ['sequence>?1'], values = [Number(after)];
  const mode = q.get('mode') || 'normal';
  if (!['normal','dev','test','all'].includes(mode)) return json({ error: 'invalid_filter' }, 400);
  if (mode !== 'all') { values.push(mode); clauses.push('mode=?' + values.length); }
  for (const key of ['game_version','build_id','balance_revision','schema_version','result']) {
    if (!q.has(key)) continue;
    const value = q.get(key);
    if (!value || value.length > 160 || !/^[a-zA-Z0-9_.|: -]+$/.test(value) || key === 'schema_version' && value !== '2' || key === 'result' && !['victory','defeat'].includes(value)) return json({ error: 'invalid_filter' }, 400);
    values.push(key === 'schema_version' ? Number(value) : value); clauses.push(key + '=?' + values.length);
  }
  values.push(Number(limit) + 1);
  const result = await env.DB.prepare('SELECT sequence,run_id,digest,received_at,report_json FROM aar_reports_v2 WHERE ' + clauses.join(' AND ') + ' ORDER BY sequence ASC LIMIT ?' + values.length).bind(...values).all();
  const rows = result.results || [], more = rows.length > Number(limit), selected = rows.slice(0, Number(limit));
  const next = more ? selected.at(-1).sequence : null;
  const reports = selected.map(row => ({ sequence: row.sequence, run_id: row.run_id, digest: row.digest, received_at: row.received_at, report: JSON.parse(row.report_json) }));
  if (format === 'jsonl') return new Response(reports.map(row => JSON.stringify(row)).join('\n') + (reports.length ? '\n' : ''), { headers: { 'Content-Type': 'application/x-ndjson; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff', 'X-AAR-Next-Cursor': next === null ? '' : String(next) } });
  return json({ reports, next_cursor: next, mode });
}
/** Returns null for all existing routes, so an audited legacy worker can handle them unchanged. */
export async function handleAAR(request, env, ctx) {
  const url = new URL(request.url);
  if (url.pathname.startsWith('/admin/v1/')) {
    if (url.pathname !== '/admin/v1/export') return json({ error: 'not_found' }, 404);
    try { return await exportReports(request, env, url); } catch { return json({ error: 'storage_unavailable' }, 503); }
  }
  if (!url.pathname.startsWith('/v1/')) return null;
  if (!['/v1/config','/v1/reports'].includes(url.pathname)) return json({ error: 'not_found' }, 404);
  const origin = request.headers.get('Origin');
  if (!origin || !origins(env).includes(origin)) return json({ error: 'origin_not_allowed' }, 403, { Vary: 'Origin' });
  const headers = { 'Access-Control-Allow-Origin': origin, 'Access-Control-Allow-Methods': 'GET, POST, OPTIONS', 'Access-Control-Allow-Headers': 'Content-Type', Vary: 'Origin' };
  const respond = (value, status) => json(value, status, headers);
  if (request.method === 'OPTIONS') return new Response(null, { status: 204, headers });
  if (url.pathname === '/v1/config') return request.method === 'GET'
    ? respond({ enabled: enabled(env), schema_version: 2, max_report_bytes: MAX_REPORT_BYTES, sitekey: enabled(env) ? env.AAR_TURNSTILE_SITEKEY : null, action: 'last_line_aar' }, 200)
    : respond({ error: 'method_not_allowed' }, 405);
  if (request.method !== 'POST') return respond({ error: 'method_not_allowed' }, 405);
  if (!enabled(env)) return respond({ error: 'uploads_disabled' }, 503);
  try {
    const rate = await env.AAR_RATE_LIMITER.limit({ key: 'aar-v2-global-ingestion' });
    if (rate.success !== true) return respond({ error: 'rate_limited', retry_after_seconds: 60 }, 429);
    if (!/^application\/json(?:\s*;|$)/i.test(request.headers.get('Content-Type') || '')) return respond({ error: 'json_required' }, 415);
    const body = await boundedBody(request, MAX_REPORT_BYTES + 4096);
    if (!body || Array.isArray(body) || typeof body !== 'object' || Object.keys(body).sort().join(',') !== 'report,turnstile_token') return respond({ error: 'invalid_envelope' }, 422);
    validateReport(body.report);
    if (enc.encode(stableJSON(body.report)).byteLength > MAX_REPORT_BYTES) return respond({ error: 'report_too_large' }, 413);
    const rejection = await verifyToken(body.turnstile_token, body.report.run_id, origin, env);
    if (rejection) return respond({ error: rejection.error }, rejection.status);
    const stored = await storeReport(body.report, env);
    const merged = new Headers(stored.headers); for (const [k,v] of Object.entries(headers)) merged.set(k,v);
    return new Response(stored.body, { status: stored.status, headers: merged });
  } catch (e) {
    if (e?.status) return respond({ error: e.error }, e.status);
    if (e?.name === 'SchemaError') return respond({ error: 'invalid_report_schema' }, 422);
    if (String(e?.message || '').includes('aar_capacity_exceeded')) return respond({ error: 'storage_capacity_reached' }, 503);
    return respond({ error: 'storage_unavailable' }, 503);
  }
}

// SOURCE: worker.mjs
// Safe parallel-service entry. Deploy only under a NEW reviewed Worker name.
// This does not replace white-queen-141d or its existing synthetic routes.
export default {
  async fetch(request, env, ctx) {
    return await handleAAR(request,env,ctx) || new Response(JSON.stringify({ service:'Last Line AAR v2', status:'staging', legacy_receiver:'unchanged' }), {
      status: new URL(request.url).pathname === '/' && request.method === 'GET' ? 200 : 404,
      headers: { 'Content-Type':'application/json', 'Cache-Control':'no-store' }
    });
  }
};
